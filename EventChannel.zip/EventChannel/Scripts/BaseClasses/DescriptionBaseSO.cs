using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// ScriptableObject�� ������ �߰��ϴ� BaseSO
/// </summary>
public class DescriptionBaseSO : ScriptableObject
{
    [TextArea] public string description;
}
